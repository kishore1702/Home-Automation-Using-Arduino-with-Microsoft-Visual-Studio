﻿using System;
using System.Speech.Recognition;
using System.Speech.Synthesis;
using System.Windows.Forms;
namespace VoiceAutomation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SpeechSynthesizer speechSynthesizerObj;
        private void Form1_Load(object sender, EventArgs e)
        {
            speechSynthesizerObj = new SpeechSynthesizer();
            speechSynthesizerObj.SpeakAsync("Welcome to the world of voice. Hope you are doing well. Give the commands.");
            SpeechRecognitionEngine sRecognize = new SpeechRecognitionEngine();
            Choices sList = new Choices();
            sList.Add(new string[] { "light on", "light off", "fan on", "fan off", "door open", "door close" });
            Grammar gr = new Grammar(new GrammarBuilder(sList));
            try
            {
                sRecognize.RequestRecognizerUpdate();
                sRecognize.LoadGrammar(gr);
                sRecognize.SpeechRecognized += sRecognize_SpeechRecognized;
                sRecognize.SetInputToDefaultAudioDevice();
                sRecognize.RecognizeAsync(RecognizeMode.Multiple);
                sRecognize.Recognize();

            }
            catch
            {
                return;
            }
        }
        private void sRecognize_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            if (e.Result.Text == "lights on")
            {
                serialPort1.Open();
                serialPort1.Write("a");
                serialPort1.Close();
            }
            else if (e.Result.Text == "lights off")
            {
                serialPort1.Open();
                serialPort1.Write("b");
                serialPort1.Close();
            }
            else if (e.Result.Text == "fan on")
            {
                serialPort1.Open();
                serialPort1.Write("c");
                serialPort1.Close();
            }
            else if (e.Result.Text == "fan off")
            {
                serialPort1.Open();
                serialPort1.Write("d");
                serialPort1.Close();
            }
            else if (e.Result.Text == "door open")
            {
                serialPort1.Open();
                serialPort1.Write("e");
                serialPort1.Close();
            }
            else if (e.Result.Text == "door close")
            {
                serialPort1.Open();
                serialPort1.Write("f");
                serialPort1.Close();
            }
        }
    }
}
